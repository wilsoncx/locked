<?php
$str_button = 'Scriptcase7_Yellow';
$str_tab_space = '1px';
$str_toolbar_separator = 'scriptcase__NM__Lightblue_separador.gif';
$str_active_col_esq = 'scriptcase__NM__v7_Yellow_iTab_L.png';
$str_active_top_esq = 'scriptcase__NM__v7_Yellow_iTab_TL.png';
$str_active_col_dir = 'scriptcase__NM__v7_Yellow_iTab_R.png';
$str_active_lin_top = 'scriptcase__NM__v7_Yellow_iTab_T.png';
$str_active_top_dir = 'scriptcase__NM__v7_Yellow_iTab_TR.png';
$str_inactive_col_esq = 'scriptcase__NM__sunnyleftinactive.gif';
$str_inactive_col_dir = 'scriptcase__NM__sunnyrightinactiv.gif';
$str_inactive_top_esq = 'scriptcase__NM__sunnycornerleftinactive.gif';
$str_inactive_lin_top = 'scriptcase__NM__sunnytopinactive.gif';
$str_inactive_top_dir = 'scriptcase__NM__sunnycornerrightinactive.gif';
?>