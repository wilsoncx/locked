<?php
$str_button = 'Scriptcase7_Pink';
$str_tab_space = '2px';
$str_toolbar_separator = 'scriptcase__NM__Lightblue_separador.gif';
$str_active_col_esq = 'scriptcase__NM__v7_Pink_aTab_L.png';
$str_active_top_esq = 'scriptcase__NM__v7_Pink_aTab_TL.png';
$str_active_col_dir = 'scriptcase__NM__v7_Pink_aTab_R.png';
$str_active_lin_top = 'scriptcase__NM__v7_Pink_aTab_T.png';
$str_active_top_dir = 'scriptcase__NM__v7_Pink_aTab_TR.png';
$str_inactive_col_esq = 'scriptcase__NM__v5GreenActTabLeft.png';
$str_inactive_col_dir = 'scriptcase__NM__v5GreenActTabRight.png';
$str_inactive_top_esq = 'scriptcase__NM__v5GreenActRoundedTabLeft.png';
$str_inactive_lin_top = 'scriptcase__NM__v5GreenActRoundedTabBgTop.png';
$str_inactive_top_dir = 'scriptcase__NM__v5GreenActRoundedTabRight.png';
?>