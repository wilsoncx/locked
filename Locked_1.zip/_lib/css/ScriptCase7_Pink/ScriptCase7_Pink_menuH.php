<?php
$str_button = 'Scriptcase7_Pink';
$str_toolbar_separator = 'scriptcase__NM__Lightblue_separador.gif';
$bg_line_degrade = array();
$bg_line_degrade[0] = '#F9EBE7';
$bg_line_degrade[1] = '#F9EBE7';
$bg_line_degrade[2] = '#F9EBE7';
$bg_line_degrade[3] = '#F9EBE7';
$str_arrow_up = 'scriptcase__NM__arrow_out_new.gif';
$str_arrow_down = 'scriptcase__NM__arrow_in_new.gif';
$str_menu_bar_background_color = '#F9EBE7';
$str_menu_sel_background_color = '#F9EBE7';
$str_item_bar_background_color = '#F9EBE7';
$str_item_bar_border_color = '#455c72';
$str_item_sel_background_color = '#F9EBE7';
$str_pagina_icon_bg = '';
?>