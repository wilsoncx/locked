<?php
$str_button = 'Scriptcase7_BlueSky';
$str_tab_space = '1px';
$str_toolbar_separator = 'scriptcase__NM__Lightblue_separador.gif';
$str_active_col_esq = 'scriptcase__NM__V7BlueSkyAba_esq.png';
$str_active_top_esq = 'scriptcase__NM__V7BlueSkyAba_te.png';
$str_active_col_dir = 'scriptcase__NM__V7BlueSkyAba_dir.png';
$str_active_lin_top = 'scriptcase__NM__V7BlueSkyAba_top.png';
$str_active_top_dir = 'scriptcase__NM__V7BlueSkyAba_td.png';
$str_inactive_col_esq = 'scriptcase__NM__V7BlueSkyAbaoff_esq.png';
$str_inactive_col_dir = 'scriptcase__NM__V7BlueSkyAbaoff_dir.png';
$str_inactive_top_esq = 'scriptcase__NM__V7BlueSkyAbaoff_te.png';
$str_inactive_lin_top = 'scriptcase__NM__V7BlueSkyAbaoff_top.png';
$str_inactive_top_dir = 'scriptcase__NM__V7BlueSkyAbaoff_td.png';
?>