<?php
$str_button = 'Sec_dbv';
$str_toolbar_separator = 'scriptcase__NM__Lightblue_separador.gif';
$str_ajax_bg = '#6e6e6e';
$str_ajax_border_c = '#8DA0C8 ';
$str_ajax_border_s = 'solid';
$str_ajax_border_w = '1px';
$str_label_sort_pos = 'right_cell';
$str_qs_image_padding = '5';
$str_label_sort = 'scriptcase__NM__V6OrderBlack.png';
$str_label_sort_asc = 'scriptcase__NM__V6BlackSortAsc.png';
$str_label_sort_desc = 'scriptcase__NM__V6BlackDesc.png';
$str_tree_exp = ' scriptcase__NM__treeviewMais.png';
$str_tree_col = 'scriptcase__NM__treeviewMenos.png';
$str_block_exp = 'scriptcase__NM__treeviewMais.png';
$str_block_col = 'scriptcase__NM__treeviewMenos.png';
$cal_ico_back = 'scriptcase__NM__img_move_left.gif';
$cal_ico_for = 'scriptcase__NM__img_move_right.gif';
$cal_ico_close = 'scriptcase__NM__img_move_close.png';
$sum_ico_line = 'scriptcase__NM__lightgray_horizontal.png';
$sum_ico_column = 'scriptcase__NM__lightgray_vertical.png';
$str_toolbarnav_separator = '';
$img_qs_search = 'scriptcase__NM__icoSearch.png';
$img_qs_clean = 'scriptcase__NM__icoSearchclose.png';
?>