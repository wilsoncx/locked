<?php
$str_button = 'Sec_dbv';
$str_tab_space = '1px';
$str_toolbar_separator = 'scriptcase__NM__Lightblue_separador.gif';
$str_active_col_esq = 'scriptcase__NM__v6WhiteActTabLeft.png';
$str_active_top_esq = 'scriptcase__NM__v6WhiteActRoundedTabLeft.png';
$str_active_col_dir = 'scriptcase__NM__v6WhiteActTabRight.png';
$str_active_lin_top = 'scriptcase__NM__v6WhiteActRoundedTabBgTop.png';
$str_active_top_dir = 'scriptcase__NM__v6WhiteActRoundedTabRight.png';
$str_inactive_col_esq = 'scriptcase__NM__v6BlueTabGreenLeft.png';
$str_inactive_col_dir = 'scriptcase__NM__v6BlueTabGreenRight.png';
$str_inactive_top_esq = 'scriptcase__NM__v6BlueRoundedTabGreenLeft.png';
$str_inactive_lin_top = 'scriptcase__NM__v6BlueRoundedTabGreenBgTop.png';
$str_inactive_top_dir = 'scriptcase__NM__v6BlueRoundedTabGreenRight.png';
?>