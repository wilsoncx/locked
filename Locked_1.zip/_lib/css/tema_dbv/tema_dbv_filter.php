<?php
$str_button = 'Sec_dbv';
$str_toolbar_separator = 'scriptcase__NM__Lightblue_separador.gif';
$str_cal_ico_back = 'scriptcase__NM__img_move_left.gif';
$str_cal_ico_for = 'scriptcase__NM__img_move_right.gif';
$str_cal_ico_close = 'scriptcase__NM__img_move_close.png';
$str_bubble_tail = 'scriptcase__NM__help_arrow.png';
$str_block_exp = 'scriptcase__NM__treeviewMais.png';
$str_block_col = 'scriptcase__NM__treeviewMenos.png';
?>