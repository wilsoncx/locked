<?php
$str_button = 'Sec_dbv';
$str_toolbar_separator = 'scriptcase__NM__Lightblue_separador.gif';
$bg_line_degrade = array();
$bg_line_degrade[0] = '';
$bg_line_degrade[1] = '';
$bg_line_degrade[2] = '';
$bg_line_degrade[3] = '';
$str_arrow_up = 'scriptcase__NM__arrow_out_new.gif';
$str_arrow_down = 'scriptcase__NM__arrow_in_new.gif';
$str_menu_bar_background_color = '';
$str_menu_sel_background_color = '#FFFFFF';
$str_item_bar_background_color = '#FFFFFF';
$str_item_bar_border_color = '#455c72';
$str_item_sel_background_color = '#F3F7FB';
$str_pagina_icon_bg = '#F3F7FB';
?>