<?php
$str_button = '';
$str_widget_max = 'scriptcase__NM__widget_max.png';
$str_widget_rest = 'scriptcase__NM__widget_res.png';
?>