<?php
$str_button = 'Scriptcase7_Black';
$str_tab_space = '1px';
$str_toolbar_separator = 'scriptcase__NM__ScriptCase7_Black_separador.png';
$str_active_col_esq = 'scriptcase__NM__v7_Black_aTab_L.png';
$str_active_top_esq = 'scriptcase__NM__v7_Black_aTab_TL.png';
$str_active_col_dir = 'scriptcase__NM__v7_Black_aTab_R.png';
$str_active_lin_top = 'scriptcase__NM__v7_Black_aTab_T.png';
$str_active_top_dir = 'scriptcase__NM__v7_Black_aTab_TR.png';
$str_inactive_col_esq = 'scriptcase__NM__v7_Black_iTab_L.png';
$str_inactive_col_dir = 'scriptcase__NM__v7_Black_iTab_R.png';
$str_inactive_top_esq = 'scriptcase__NM__v7_Black_iTab_TL.png';
$str_inactive_lin_top = 'scriptcase__NM__v7_Black_iTab_T.png';
$str_inactive_top_dir = 'scriptcase__NM__v7_Black_iTab_TR.png';
?>