<?php
$str_button = 'ScriptCase6_Cromo';
$str_tab_space = '1px';
$str_toolbar_separator = 'scriptcase__NM__Lightblue_separador.gif';
$str_active_col_esq = 'scriptcase__NM__V6CromoAba_esq.png';
$str_active_top_esq = 'scriptcase__NM__V6CromoAba_te.png';
$str_active_col_dir = 'scriptcase__NM__V6CromoAba_dir.png';
$str_active_lin_top = 'scriptcase__NM__V6CromoAba_top.png';
$str_active_top_dir = 'scriptcase__NM__V6CromoAba_td.png';
$str_inactive_col_esq = 'scriptcase__NM__V6CromoAbaoff_esq.png';
$str_inactive_col_dir = 'scriptcase__NM__V6CromoAbaoff_dir.png';
$str_inactive_top_esq = 'scriptcase__NM__V6CromoAbaoff_te.png';
$str_inactive_lin_top = 'scriptcase__NM__V6CromoAbaoff_top.png';
$str_inactive_top_dir = 'scriptcase__NM__V6CromoAbaoff_td.png';
?>