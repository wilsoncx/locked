<?PHP
    phpinfo();
?>
