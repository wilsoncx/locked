<?php
  $this->Nm_lang_conf_region = array();
  $this->Nm_lang_conf_region['pt_br;pt_br'] = "Portuguese (Brazil)";
  ksort($this->Nm_lang_conf_region);
?>